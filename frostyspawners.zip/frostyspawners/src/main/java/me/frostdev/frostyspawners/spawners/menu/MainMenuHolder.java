package me.frostdev.frostyspawners.spawners.menu;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public class MainMenuHolder implements InventoryHolder {
    public MainMenuHolder() {
    }

    public Inventory getInventory() {
        return null;
    }
}

