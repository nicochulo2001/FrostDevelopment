package me.frostdev.frostyspawners.spawners.menu;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public class SettingsMenuHolder implements InventoryHolder {
    public SettingsMenuHolder() {
    }

    public Inventory getInventory() {
        return null;
    }
}
