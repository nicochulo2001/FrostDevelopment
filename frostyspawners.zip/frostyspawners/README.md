########### { Frosty Spawners} ##########
### {
Full Featured Spawner Management Plug-in by MagnusFrost} ###
-{Description}-
Frost Spawners was developed in-house specifically for the HelloMiners Minecraft Server. Its features include a fully fledged GUI,  upgrades, entity selection, on/off button, and an extensive suite of administrative commands for fine tuned control. 
-{Spawner Upgrades}-
Spawner Upgrades mainly do two things: 
Decreases entity spawn delay 
Allows for more powerful/profitable mob type selection. 
-{Enable/Disable}-
The enable/disable button does exactly what you think. This allows you to turn your spawner on or off at will. (redstone control coming soon)
-{Spawner Lock}-
The spawner lock is primarily an admin tool that disallows the spawners owner from accessing a spawners GUI.
-{Entity Type}-
Entity type selection menu is fully configurable and allows just about any mob in the game to be spawned from the spawner. Each mob has its own cost and level requirements. Mobs can also be enabled and disabled in the configuration. Be aware that certain mob types require certain room conditions to be met in order to spawn. (Feature and Guide coming soon)
-{How}-
Admin team please fill this out. 
Tell me if you want an npc to give out spawners or you just want to put the spawner item itself in the vote loot table. 
