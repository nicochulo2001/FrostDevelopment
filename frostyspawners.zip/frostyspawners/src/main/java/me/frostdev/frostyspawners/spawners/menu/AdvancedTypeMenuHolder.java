package me.frostdev.frostyspawners.spawners.menu;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public class AdvancedTypeMenuHolder implements InventoryHolder {
    public AdvancedTypeMenuHolder() {
    }

    public Inventory getInventory() {
        return null;
    }
}

