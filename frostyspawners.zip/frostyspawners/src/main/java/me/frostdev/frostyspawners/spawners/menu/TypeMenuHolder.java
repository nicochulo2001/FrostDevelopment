package me.frostdev.frostyspawners.spawners.menu;


import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public class TypeMenuHolder implements InventoryHolder {
    public TypeMenuHolder() {
    }

    public Inventory getInventory() {
        return null;
    }
}
